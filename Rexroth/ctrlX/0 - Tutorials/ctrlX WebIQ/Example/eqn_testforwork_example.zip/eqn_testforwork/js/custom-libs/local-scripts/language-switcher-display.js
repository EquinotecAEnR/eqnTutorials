(function () {

    /**
     * replace module name with a custom name for the local-script.
     *
     * All local-script should be attached to the "custom.ls" package.
     * If more than one script is required for an application, a common root package
     * should be created (e.g. "custom.ls.customerName.*").
     */

    var MODULE_NAME = "language-switcher-display",
        ENABLE_LOGGING = false,
        RECORD_LOG = false,
        logger = shmi.requires("visuals.tools.logging").createLogger(MODULE_NAME, ENABLE_LOGGING, RECORD_LOG),
        fLog = logger.fLog,
        log = logger.log,
        module = shmi.pkg( MODULE_NAME );

    // MODULE CODE - START

    /**
     * Implements local-script run function.
     *
     * This function will be called each time a local-script will be enabled.
     *
     * @param {LocalScript} self instance reference of local-script control
     */
    module.run = function (self) {
        
        // Get the User Manager instance
        const um = shmi.requires("visuals.session.UserManager");
        
        // Place your Code here
        shmi.onReady(
        {
            controls: {
                button: ".language-selection"
            }
        }, function (resolved) {
            // The retrieved widget instance
            const myButtonWidget = resolved.controls.button;
            
            // Getting the label to display
            // de-DE -> de, en-GB -> en usw.
            let locale = um.currentUser.locale;
            const matches = locale.match(/^([a-z]+)-/, locale);
            
            if (matches) {
                locale = matches[1];
            }
            
            // Setting the locale label in the button
            myButtonWidget.setLabel(locale);
        });

        /* called when this local-script is disabled */
        self.onDisable = function () {
            self.run = false; /* from original .onDisable function of LocalScript control */
        };
    };

    // MODULE CODE - END

    fLog("module loaded");
})();
